﻿//=============================================================================
// NRP_BitmapSmoothOff.js
//=============================================================================
/*:
 * @target MZ
 * @plugindesc v1.01 Removes noise generated in the image.
 * @author Takeshi Sunagawa (http://newrpg.seesaa.net/)
 * @url http://newrpg.seesaa.net/article/484654081.html
 *
 * @help Removes noise generated in the image.
 * 
 * When you move the battler in RPG Maker MZ,
 * the image may have noises like lines.
 * 
 * This is caused by an internal fractional number calculation
 * that shifts the image cropping position by one pixel.
 * ※The identity of the line is the SV actor itself or the state icon.
 *   The edge of the neighboring image pattern is supposed to be displayed.
 * 
 * This problem can be solved by switching the settings for the image.
 * 
 * -------------------------------------------------------------------
 * [Usage]
 * -------------------------------------------------------------------
 * Just apply it.
 * You can switch between them for each image,
 * but the default state is usually fine.
 * 
 * -------------------------------------------------------------------
 * [Terms]
 * -------------------------------------------------------------------
 * There are no restrictions.
 * Modification, redistribution freedom, commercial availability,
 * and rights indication are also optional.
 * The author is not responsible,
 * but will deal with defects to the extent possible.
 * 
 * @param SvActorSmoothOff
 * @type boolean
 * @default true
 * @desc Apply the process to the SV actor image.
 * 
 * @param StateIconSmoothOff
 * @type boolean
 * @default true
 * @desc Apply the process to the state icon image.
 * 
 * @param AnimationSmoothOff
 * @type boolean
 * @default true
 * @desc Apply the process to the animation image (MV Style).
 */

/*:ja
 * @target MZ
 * @plugindesc v1.01 画像に発生するノイズを除去
 * @author 砂川赳（http://newrpg.seesaa.net/）
 * @url http://newrpg.seesaa.net/article/484654081.html
 *
 * @help 画像に発生するノイズを除去します。
 * 
 * ツクールＭＺにて、バトラーを移動させた場合、
 * 画像に線のようなノイズが入ることがあります。
 * 
 * これは内部的な処理における小数値の計算により、
 * 画像を切り抜く位置が１ピクセルズレることによって発生します。
 * ※線の正体はＳＶアクター自身やステートアイコンです。
 * 　隣の画像パターンの端が表示されていると思われます。
 * 
 * 画像に対する設定を切り替えることによって、この問題を解決します。
 * 
 * -------------------------------------------------------------------
 * ■使用方法
 * -------------------------------------------------------------------
 * 適用するだけでＯＫです。
 * 画像毎に切り替えられるようになっていますが、
 * 通常は初期状態でも問題ないと思います。
 * 
 * -------------------------------------------------------------------
 * ■利用規約
 * -------------------------------------------------------------------
 * 特に制約はありません。
 * 改変、再配布自由、商用可、権利表示も任意です。
 * 作者は責任を負いませんが、不具合については可能な範囲で対応します。
 * 
 * @param SvActorSmoothOff
 * @text ＳＶアクターに適用
 * @type boolean
 * @default true
 * @desc ＳＶアクター画像に処理を適用します。
 * 
 * @param StateIconSmoothOff
 * @text ステートアイコンに適用
 * @type boolean
 * @default true
 * @desc ステートアイコン画像に処理を適用します。
 * 
 * @param AnimationSmoothOff
 * @text アニメーションに適用
 * @type boolean
 * @default true
 * @desc アニメーション画像（ＭＶ形式）に処理を適用します。
 */

(function() {
"use strict";

function toBoolean(str, def) {
    if (str === true || str === "true") {
        return true;
    } else if (str === false || str === "false") {
        return false;
    }
    return def;
}

const PLUGIN_NAME = "NRP_BitmapSmoothOff";
const parameters = PluginManager.parameters(PLUGIN_NAME);
const pSvActorSmoothOff = toBoolean(parameters["SvActorSmoothOff"], true);
const pStateIconSmoothOff = toBoolean(parameters["StateIconSmoothOff"], true);
const pAnimationSmoothOff = toBoolean(parameters["AnimationSmoothOff"], true);

if (pSvActorSmoothOff) {
    /**
     * ●ＳＶアクターの読込
     * ※Sprite_Actor.prototype.updateBitmapでもよいが、
     * 　あちらは常駐処理なので、こちらで対応
     */
    const _ImageManager_loadSvActor = ImageManager.loadSvActor;
    ImageManager.loadSvActor = function(filename) {
        const bitmap = _ImageManager_loadSvActor.apply(this, arguments);
        bitmap.smooth = false;
        return bitmap;
    };
}

if (pStateIconSmoothOff) {
    /**
     * ●ステートアイコンの読込
     */
    const _Sprite_StateIcon_loadBitmap = Sprite_StateIcon.prototype.loadBitmap;
    Sprite_StateIcon.prototype.loadBitmap = function() {
        _Sprite_StateIcon_loadBitmap.apply(this, arguments);
        this.bitmap.smooth = false;
    };
}

if (pAnimationSmoothOff) {
    /**
     * ●アニメーションの読込
     */
    const _Sprite_AnimationMV_loadBitmaps = Sprite_AnimationMV.prototype.loadBitmaps;
    Sprite_AnimationMV.prototype.loadBitmaps = function() {
        _Sprite_AnimationMV_loadBitmaps.apply(this, arguments);
        this._bitmap1.smooth = false;
        this._bitmap2.smooth = false
    };
}

})();
